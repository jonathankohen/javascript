$('img.ninja').click(function () {
    $(this).hide();
    console.log('clicked');
});

$('#restore').click(function () {
    $('img').show();
});
