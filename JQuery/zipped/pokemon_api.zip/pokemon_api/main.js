$(document).ready(function () {
    for (let i = 0; i <= 151; i++) {
        console.log('looped');
        if (i != 0) {
            $('#images_section').append(
                `<img src='https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/${i}.png' alt='Pokemon'>`
            );
        }
    }
});
